name = input("Bitte geben Sie den Namen ein: ")
print("Hallo", name, "!")
print("Auf Wiedersehen!")